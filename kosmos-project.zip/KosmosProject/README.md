# Kosmos source workspace

This archive contains the project source and workspace packages, including the redesigned Kosmos frontend at `artifacts/kosmos`. Installed dependencies, generated build output, local agent files, uploaded reference files, and environment secrets are not included.

To run locally with pnpm, install dependencies and start Kosmos with the required Vite environment:

```sh
pnpm install
PORT=5000 BASE_PATH=/kosmos/ pnpm --filter @workspace/kosmos run dev
```
