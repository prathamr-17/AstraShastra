import { useEffect } from 'react';
import { ArrowLeft, Orbit } from 'lucide-react';
import { useAnimeInteractions } from '@/hooks/use-anime-interactions';

export default function NotFound() {
  useAnimeInteractions();
  useEffect(() => {
    document.title = 'Page not found | Kosmos';
  }, []);
  return (
    <main className="not-found">
      <div className="not-found-stars" aria-hidden="true" />
      <div className="not-found-shell">
        <a href="/" className="footer-brand" aria-label="Kosmos home"><i aria-hidden="true" />Kosmos</a>
        <div className="not-found-orbit" aria-hidden="true"><Orbit size={46} strokeWidth={1} /><span>404</span></div>
        <p className="eyebrow">Signal not found / 404</p>
        <h1>Nothing in this orbit.</h1>
        <p className="not-found-copy">This address has drifted beyond the map. The Kosmos runtime is still right where you left it.</p>
        <a href="/" className="button-primary" data-testid="link-not-found-home"><ArrowLeft size={15} /> Return to Kosmos</a>
      </div>
      <span className="not-found-coordinate">KOSMOS / OUTER PERIMETER</span>
    </main>
  );
}