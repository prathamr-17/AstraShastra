import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import {
  Activity, ArrowDownRight, ArrowRight, ArrowUpRight, Ban, Check, ChevronDown,
  CircleAlert, CircleCheck, Database, Eye, FileKey2, Fingerprint, Link2,
  LockKeyhole, Menu, Network, Radar, ScanLine, ServerCog, ShieldCheck, X,
} from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { useAnimeInteractions } from '@/hooks/use-anime-interactions';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

type Outcome = 'allow' | 'flag' | 'halt';
type Scenario = {
  id: string;
  agent: string;
  action: string;
  outcome: Outcome;
  reason: string;
  signals: string;
  score: number;
};
type AuditEvent = Scenario & { time: string; eventId: number };

const scenarios: Scenario[] = [
  { id: 'vendor-check', agent: 'procurement.route_7', action: 'vendor.lookup', outcome: 'allow', reason: 'Within signed contract scope; vendor is on the approved list.', signals: 'rate: normal · novelty: low', score: 94 },
  { id: 'invoice-spike', agent: 'procurement.route_7', action: 'invoice.create', outcome: 'flag', reason: 'Request volume is above the contract threshold. Operator review is required.', signals: 'rate: +2.1σ · novelty: moderate', score: 68 },
  { id: 'payment-diversion', agent: 'procurement.route_7', action: 'payments.transfer', outcome: 'halt', reason: 'Beneficiary is outside the signed policy. The call was stopped before execution.', signals: 'rate: normal · policy: violated', score: 21 },
];

function Reveal({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <div className={`reveal is-visible ${className}`}>{children}</div>;
}

function Brand({ footer = false }: { footer?: boolean }) {
  return <a href="#top" className="footer-brand" aria-label="Kosmos, back to top" data-testid={footer ? 'link-footer-brand' : 'link-brand'}><i aria-hidden="true" />Kosmos</a>;
}

function Header({ onRequest }: { onRequest: () => void }) {
  const [open, setOpen] = useState(false);
  useAnimeInteractions('.mobile-nav', open);
  const close = () => setOpen(false);
  const links = [['#problem', 'The trust gap'], ['#runtime', 'Runtime layer'], ['#network', 'Network watch'], ['#threat-model', 'Threat model'], ['#architecture', 'Architecture']];
  return (
    <header className="site-header">
      <div className="container-wide header-inner">
        <Brand />
        <nav className="desktop-nav" aria-label="Primary navigation">
          {links.map(([href, label]) => <a className="nav-link" href={href} key={href}>{label}</a>)}
        </nav>
        <div className="header-actions">
          <button className="button-primary header-cta" onClick={onRequest} data-testid="button-request-access-top">Request a walkthrough <ArrowUpRight size={15} /></button>
          <button className="menu-button" onClick={() => setOpen((v) => !v)} aria-label={open ? 'Close navigation' : 'Open navigation'} aria-expanded={open} aria-controls="mobile-navigation" data-testid="button-mobile-menu">{open ? <X size={19} /> : <Menu size={19} />}</button>
        </div>
        {open && <nav className="mobile-nav" id="mobile-navigation" aria-label="Mobile navigation">
          {links.map(([href, label]) => <a href={href} onClick={close} key={href}>{label}<ArrowRight size={14} /></a>)}
          <a href="#contact" onClick={close}>Contact <ArrowRight size={14} /></a>
          <button className="button-primary mobile-nav-cta" onClick={() => { close(); onRequest(); }}>Request a walkthrough <ArrowUpRight size={14} /></button>
        </nav>}
      </div>
    </header>
  );
}

function Hero({ onRequest }: { onRequest: () => void }) {
  return <section className="hero" id="top" data-testid="section-hero">
    <div className="hero-grid" aria-hidden="true" /><div className="starfield" aria-hidden="true" />
    <div className="black-hole" aria-hidden="true"><div className="hole-glow" /><div className="orbit-trace" /><div className="hole-ring" /></div>
    <Header onRequest={onRequest} />
    <div className="container-wide"><div className="hero-copy"><Reveal>
      <div className="eyebrow"><span className="eyebrow-mark" /> Agent runtime security / 001</div>
      <h1 className="display">Trust is decided<br />at the <em>boundary.</em></h1>
      <p className="hero-lede">Kosmos verifies autonomous agent actions at tool-call time. Every decision is visible, explainable, and written to an auditable history.</p>
      <div className="hero-actions"><a className="button-primary" href="#runtime" data-testid="link-see-runtime">Run the local demo <ArrowDownRight size={16} /></a><button className="button-ghost" onClick={onRequest}>Explore the approach <ArrowUpRight size={15} /></button></div>
      <div className="hero-meta" aria-label="Kosmos capabilities">
        <div className="hero-meta-item"><strong>01</strong><span>verify before execution</span></div>
        <div className="hero-meta-item"><strong>02</strong><span>explain every decision</span></div>
        <div className="hero-meta-item"><strong>03</strong><span>keep the full history</span></div>
      </div>
    </Reveal></div></div>
    <div className="hero-scroll"><i aria-hidden="true" /> Scroll to inspect</div>
    <div className="hero-index">K / 01<br /><span>GUARDRAIL ACTIVE</span></div>
  </section>;
}

function TrustGap() {
  return <section className="section-pad section-dark" id="problem" data-testid="section-trust-gap"><div className="container-wide">
    <Reveal><div className="trust-layout"><h2 className="statement">A trusted tool can still become a <span>threat.</span></h2><div className="trust-aside"><div className="quote-mark" aria-hidden="true">“</div><p>The risk is not always a stolen credential. It can be a compromised agent using a valid tool, in a valid session, with an invalid goal.</p><a href="#threat-model" className="button-ghost">See the failure mode <ArrowDownRight size={15} /></a></div></div></Reveal>
    <Reveal className="reveal-delay-2"><div className="fact-grid">
      <div className="fact"><b>TOOL-CALL</b><span>Observe where model intent becomes real-world action.</span></div>
      <div className="fact"><b>EXPLAINABLE</b><span>Rate, novelty, and policy signals—not a black-box verdict.</span></div>
      <div className="fact"><b>APPEND-ONLY</b><span>A tamper-evident trace of every allow, flag, and halt.</span></div>
    </div></Reveal>
  </div></section>;
}

const phases = [
  { number: '01', title: 'Authenticate', body: 'Verify signed agent identity and active policy.', icon: Fingerprint },
  { number: '02', title: 'Intercept', body: 'Inspect each action at the execution boundary.', icon: ScanLine },
  { number: '03', title: 'Evaluate', body: 'Check contract scope and transparent risk signals.', icon: Radar },
  { number: '04', title: 'Respond', body: 'Allow, flag, or halt—and record the reason.', icon: FileKey2 },
];

function Boundary() {
  return <section className="section-pad section-panel boundary" id="boundary"><div className="container-wide">
    <Reveal><div className="boundary-head"><div><div className="eyebrow">The control plane</div><h2 className="display">Trust is a runtime decision.</h2></div><p>Not a postmortem. Not another prompt. A bounded policy layer between intention and execution.</p></div></Reveal>
    <div className="boundary-layout"><div className="boundary-line">{phases.map((phase, i) => { const Icon = phase.icon; return <Reveal key={phase.number} className={`phase reveal-delay-${i + 1}`}><div className="phase-dot"><Icon size={11} aria-hidden="true" /></div><div className="phase-number">{phase.number}</div><h3>{phase.title}</h3><p>{phase.body}</p></Reveal>; })}</div>
      <Reveal className="reveal-delay-2"><aside className="side-note"><b>Why this boundary</b>A harmless-looking response can trigger a consequential tool call. Kosmos evaluates the action itself—not just the prose around it.</aside></Reveal>
    </div>
  </div></section>;
}

function RuntimeConsole() {
  const [scenarioId, setScenarioId] = useState(scenarios[0].id);
  const [event, setEvent] = useState<AuditEvent | null>(null);
  const [history, setHistory] = useState<AuditEvent[]>([]);
  const [running, setRunning] = useState(false);
  const [runtimeError, setRuntimeError] = useState('');
  const selected = scenarios.find((scenario) => scenario.id === scenarioId) ?? scenarios[0];

  const run = () => {
    if (running) return;
    setRuntimeError('');
    setRunning(true);
    window.setTimeout(() => {
      try {
        const result: AuditEvent = { ...selected, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }), eventId: Date.now() };
        const next = [result, ...history].slice(0, 5);
        try { window.localStorage.setItem('kosmos-demo-audit', JSON.stringify(next)); } catch { /* Demo works in private storage too. */ }
        setEvent(result);
        setHistory(next);
      } catch {
        setRuntimeError('The local demo could not complete this run. Try the scenario again.');
      } finally { setRunning(false); }
    }, 420);
  };

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem('kosmos-demo-audit');
      if (stored) {
        const parsed: unknown = JSON.parse(stored);
        if (Array.isArray(parsed)) setHistory(parsed.slice(0, 5) as AuditEvent[]);
      }
    } catch { setHistory([]); }
  }, []);

  const OutcomeIcon = event?.outcome === 'halt' ? Ban : event?.outcome === 'flag' ? CircleAlert : CircleCheck;
  return <section className="section-pad runtime-section" id="runtime" data-testid="section-runtime"><div className="container-wide"><div className="runtime-grid">
    <Reveal><div className="runtime-copy"><div className="eyebrow">Interactive / deterministic local demo</div><h2 className="display">See the decision before the action.</h2><p>Choose a predefined tool-call scenario and run it through a local policy check. No backend, no network requests—just a realistic, repeatable view of allow, flag, and halt decisions.</p><ul className="runtime-list"><li><Check size={15} /> Signed behavior contracts in JSON or YAML</li><li><Check size={15} /> Rate and novelty scoring with visible reasons</li><li><Check size={15} /> Fail-closed decisions at the tool boundary</li></ul><div className="runtime-local-note"><LockKeyhole size={14} /> Runs entirely in this browser. Demo history is stored locally.</div></div></Reveal>
    <Reveal className="reveal-delay-2"><div className="console" data-testid="runtime-console">
      <div className="console-top"><div className="console-dots"><i /><i /><i /></div><span>KOSMOS / POLICY TRACE</span><div className="console-status"><i /> local runtime</div></div>
      <div className="console-controls"><label htmlFor="scenario-select">SCENARIO</label><div className="scenario-select-wrap"><select id="scenario-select" value={scenarioId} onChange={(e) => { setScenarioId(e.target.value); setRuntimeError(''); }} data-testid="select-demo-scenario"><option value="vendor-check">Approved vendor lookup</option><option value="invoice-spike">Unusual invoice volume</option><option value="payment-diversion">Unapproved payment recipient</option></select><ChevronDown size={15} aria-hidden="true" /></div><button className="run-button" onClick={run} disabled={running} data-testid="button-run-scenario">{running ? 'Evaluating…' : 'Evaluate action'} <ArrowRight size={15} /></button></div>
      {runtimeError && <p className="inline-feedback error" role="alert" data-testid="status-runtime-error"><CircleAlert size={15} />{runtimeError}</p>}
      <div className="console-body">
        <div className="console-agent"><div><div className="agent-label">agent identity</div><div className="agent-name">{event?.agent ?? selected.agent}</div></div><div className="score"><b>{event?.score ?? selected.score}</b><span>POLICY SCORE / 100</span></div></div>
        <div className="trace-request"><span>TOOL CALL</span><strong>{event?.action ?? selected.action}</strong><small>signed contract · procurement-v3</small></div>
        {event ? <div className={`result-panel ${event.outcome}`} aria-live="polite" data-testid="status-runtime-result"><div className="result-head"><span className="result-icon"><OutcomeIcon size={17} /></span><strong>{event.outcome.toUpperCase()}</strong><time>{event.time}</time></div><p>{event.reason}</p><small>{event.signals}</small></div> : <div className="result-placeholder"><Activity size={17} /><span>Ready to inspect this action. Choose a scenario, then evaluate.</span></div>}
        {history.length > 0 && <div className="runtime-history"><div className="history-heading">LOCAL DECISION HISTORY <span>{history.length} {history.length === 1 ? 'event' : 'events'}</span></div>{history.slice(0, 3).map((item) => <div className="history-row" key={item.eventId}><span className={`history-dot ${item.outcome}`} /><code>{item.action}</code><b className={item.outcome}>{item.outcome}</b><time>{item.time}</time></div>)}</div>}
      </div>
      <div className="console-foot"><span><i /> Nothing is sent. This is a local product demonstration.</span><button onClick={() => { setHistory([]); setEvent(null); setRuntimeError(''); try { window.localStorage.removeItem('kosmos-demo-audit'); } catch { setRuntimeError('Could not clear local browser storage.'); } }} data-testid="button-clear-history" disabled={history.length === 0 && !event}>Clear local history</button></div>
    </div></Reveal>
  </div></div></section>;
}

const monitoredAgents = [
  { name: 'procurement.route_7', role: 'procurement', score: '94', status: 'observing', tone: 'healthy' },
  { name: 'research.synth_2', role: 'research', score: '88', status: 'observing', tone: 'healthy' },
  { name: 'fulfillment.ops_4', role: 'fulfillment', score: '61', status: 'flagged', tone: 'flagged' },
];

function NetworkWatch() {
  return <section className="section-pad section-panel network-watch" id="network" data-testid="section-network-watch"><div className="container-wide">
    <Reveal><div className="network-head"><div><div className="eyebrow">Continuous network watch</div><h2 className="display">Every agent in view.</h2></div><p>Keep a perimeter around the multi-agent network. Compare live behavior to policy and surface drift before it compounds.</p></div></Reveal>
    <div className="network-grid"><Reveal className="reveal-delay-1"><div className="network-summary"><div className="network-summary-top"><span className="network-live"><i /> illustrative network state</span><Network size={18} aria-hidden="true" /></div><div className="network-stat-grid"><div><b>12</b><span>agents online</span></div><div><b>100%</b><span>actions observed</span></div><div><b>03</b><span>interventions today</span></div><div><b>00</b><span>unverified policies</span></div></div><div className="coverage-bar"><div className="coverage-label"><span>network coverage</span><strong>nominal</strong></div><div className="coverage-track"><i /></div><small>Illustrative product state. Connectors are not active in this demo.</small></div></div></Reveal>
      <Reveal className="reveal-delay-2"><div className="agent-roster" data-testid="agent-roster"><div className="roster-top"><span>monitored agents</span><span>trust / state</span></div>{monitoredAgents.map((agent) => <div className="agent-row" key={agent.name}><div className="agent-node" aria-hidden="true"><i /></div><div className="agent-identity"><strong>{agent.name}</strong><span>{agent.role} · sidecar connected</span></div><div className="agent-health"><b className={agent.tone}>{agent.score}</b><span className={agent.tone}>{agent.status}</span></div></div>)}<div className="roster-foot"><span />Flagged agents stay visible, isolated, and reviewable.</div></div></Reveal>
    </div>
  </div></section>;
}

function ThreatModel() {
  return <section className="section-pad threat" id="threat-model" data-testid="section-threat-model"><div className="container-wide"><div className="threat-layout">
    <Reveal><div className="threat-copy"><div className="eyebrow">Scenario / tool poisoning</div><h2 className="display">Stop the rug pull before the payment.</h2><p>A procurement agent reads a poisoned document. Its credentials still work. The next call does not belong. Kosmos turns a silent compromise into an early, auditable, reversible event.</p><a className="threat-demo-link" href="#runtime">Run the payment-diversion scenario <ArrowUpRight size={14} /></a></div></Reveal>
    <div className="threat-steps"><Reveal><div className="threat-step alert"><b>01</b><div><h3>Block the action</h3><p>Out-of-scope API calls stop inline.</p></div><Ban size={22} /></div></Reveal><Reveal className="reveal-delay-1"><div className="threat-step"><b>02</b><div><h3>Isolate the agent</h3><p>Pause activity while an operator reviews.</p></div><LockKeyhole size={22} /></div></Reveal><Reveal className="reveal-delay-2"><div className="threat-step"><b>03</b><div><h3>Explain the decision</h3><p>Every reason travels with its audit event.</p></div><Eye size={22} /></div></Reveal></div>
  </div></div></section>;
}

function Ledger() {
  const blocks = [['#8F2A', 'agent.auth', 'a4f0…7d9b'], ['#8F2B', 'vendor.lookup', '12c8…1a41'], ['#8F2C', 'invoice.create', 'a907…d2e4'], ['#8F2D', 'payments.halt', 'f6b1…09ac']];
  return <section className="section-pad section-dark" id="ledger" data-testid="section-ledger"><div className="container-wide"><div className="ledger-layout">
    <Reveal><div className="ledger-copy"><div className="eyebrow">Accountability layer</div><h2 className="display">Memory is part of the defense.</h2><p>Decisions can be appended to a SHA-256 hash-chained ledger. Rewrite a past event and the chain breaks—a compact record an operator can inspect.</p><a href="#architecture" className="button-ghost" style={{ marginTop: 30 }}>Explore the architecture <ArrowDownRight size={15} /></a></div></Reveal>
    <Reveal className="reveal-delay-2"><div className="hash-chain" data-testid="hash-chain"><div className="chain-label"><span>illustrative decision ledger</span><span>integrity: intact</span></div><div className="blocks">{blocks.map(([id, event, hash]) => <div className="block" key={id}><b>{id}</b><strong>{event}</strong><small>prev_hash<br />{hash}</small></div>)}</div><p className="ledger-caption"><Link2 size={12} />The latest hash can be anchored outside the database.</p></div></Reveal>
  </div></div></section>;
}

const architecture = [
  { title: 'Sidecar interceptor', copy: 'A FastAPI boundary captures tool calls without rewriting agent logic.', icon: ServerCog },
  { title: 'Signed contracts', copy: 'Readable JSON or YAML policies set the intended operating envelope.', icon: FileKey2 },
  { title: 'Integrity monitor', copy: 'Identity, policy enforcement, scoring, and audit in one runtime.', icon: ShieldCheck },
  { title: 'Transparent risk signals', copy: 'Rate and novelty turn unusual behavior into a reasoned flag.', icon: Activity },
  { title: 'Fail-closed response', copy: 'Allow, flag, throttle, or halt with clear operator review paths.', icon: LockKeyhole },
  { title: 'Local observability', copy: 'SQLite plus a lightweight dashboard; offline-friendly by design.', icon: Database },
];

function Architecture() {
  return <section className="section-pad architecture" id="architecture" data-testid="section-architecture"><div className="container-wide"><Reveal><div className="arch-head"><div><div className="eyebrow">Designed for the runtime you have</div><h2 className="display">Small modules. Serious perimeter.</h2></div><p>Python 3 · FastAPI · SQLite · SHA-256<br />No model retraining required.</p></div></Reveal><div className="arch-grid">{architecture.map((item, i) => { const Icon = item.icon; return <Reveal key={item.title} className={`reveal-delay-${(i % 4) + 1}`}><article className="arch-card"><div className="arch-icon"><Icon size={17} /></div><h3>{item.title}</h3><p>{item.copy}</p></article></Reveal>; })}</div><div className="arch-foot"><span />Verify-then-trust for autonomous and multi-agent networks</div></div></section>;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const STORAGE_KEY = 'kosmos-demo-interest';
function Contact() {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setMessage(''); setError('');
    const normalized = email.trim();
    if (!EMAIL_RE.test(normalized)) { setError('Enter a valid work email address to save this demo request.'); return; }
    try {
      const records = JSON.parse(window.localStorage.getItem(STORAGE_KEY) ?? '[]') as string[];
      if (records.includes(normalized)) { setError('This address is already saved in this browser.'); return; }
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify([...records, normalized]));
      setMessage('Saved in this browser. Nothing was sent to Kosmos or any external service.');
      setEmail('');
    } catch { setError('Your browser could not save this request. Check local storage settings and try again.'); }
  };
  return <section className="section-pad cta" id="contact" data-testid="section-contact"><div className="cta-orbit" aria-hidden="true" /><div className="container-wide cta-inner"><Reveal><div><div className="eyebrow">A clearer view starts here</div><h2 className="display">See what your agents are <span>really doing.</span></h2><form className="contact-form" onSubmit={submit} noValidate><label htmlFor="contact-email">Work email</label><div className="contact-fields"><input id="contact-email" className="input-field" type="email" autoComplete="email" value={email} onChange={(e) => { setEmail(e.target.value); setError(''); setMessage(''); }} placeholder="you@company.com" aria-invalid={!!error} aria-describedby={error ? 'contact-error' : 'contact-note'} data-testid="input-contact-email" /><button className="button-primary" type="submit" data-testid="button-contact-submit">Save demo request <ArrowUpRight size={15} /></button></div>{error ? <p id="contact-error" className="form-note inline-feedback error" role="alert" data-testid="status-contact-error"><CircleAlert size={14} />{error}</p> : message ? <p className="form-note inline-feedback success" role="status" data-testid="status-contact-submitted"><CircleCheck size={14} />{message}</p> : <p id="contact-note" className="form-note">Local prototype only. Your email stays in this browser; no request is sent.</p>}</form></div></Reveal><div className="cta-side-note"><span>LOCAL DEMO</span><p>There is no signup backend connected.</p><a href="#runtime">Try the runtime <ArrowRight size={14} /></a></div></div></section>;
}

function Footer() {
  const footerLinks = [
    ['#problem', 'Trust gap'],
    ['#runtime', 'Runtime demo'],
    ['#network', 'Network watch'],
    ['#threat-model', 'Threat model'],
    ['#architecture', 'Architecture'],
    ['#contact', 'Contact'],
  ];

  return (
    <footer>
      <div className="container-wide footer-row">
        <Brand footer />
        <nav className="footer-links" aria-label="Footer navigation">
          {footerLinks.map(([href, label]) => (
            <a href={href} key={href}>{label}</a>
          ))}
        </nav>
        <span className="footer-tagline">Runtime integrity for autonomous systems</span>
        <span>© {new Date().getFullYear()} KOSMOS</span>
        <a href="#top" className="back-top">Back to top ↑</a>
      </div>
    </footer>
  );
}

function RequestModal({ onClose }: { onClose: () => void }) {
  useAnimeInteractions('.modal');
  const [email, setEmail] = useState('');
  const [feedback, setFeedback] = useState('');
  const [error, setError] = useState('');
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setFeedback(''); setError('');
    const value = email.trim();
    if (!EMAIL_RE.test(value)) { setError('Enter a valid email address.'); return; }
    try {
      const requests = JSON.parse(window.localStorage.getItem(STORAGE_KEY) ?? '[]') as string[];
      if (requests.includes(value)) { setError('This address is already saved in this browser.'); return; }
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify([...requests, value]));
      setFeedback('Your demo request is saved locally. Nothing was sent.');
    } catch { setError('Could not save in this browser. Please try again.'); }
  };
  return <div className="modal-backdrop" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}><div className="modal" role="dialog" aria-modal="true" aria-labelledby="request-title"><div className="modal-top"><div><div className="eyebrow">Kosmos / private preview</div><h2 id="request-title">Put a guard at the boundary.</h2></div><button className="modal-close" onClick={onClose} aria-label="Close request dialog" data-testid="button-close-modal"><X size={18} /></button></div><p>Save a local demo request and explore how policy decisions work. No account creation or external submission.</p><form className="contact-form" onSubmit={submit} noValidate><label htmlFor="modal-email">Work email</label><div className="contact-fields"><input id="modal-email" className="input-field" type="email" autoComplete="email" value={email} onChange={(e) => { setEmail(e.target.value); setError(''); setFeedback(''); }} placeholder="you@company.com" aria-invalid={!!error} data-testid="input-modal-email" /><button className="button-primary" type="submit" data-testid="button-modal-submit">Save locally <ArrowUpRight size={15} /></button></div>{error && <p className="inline-feedback error" role="alert" data-testid="status-modal-error"><CircleAlert size={14} />{error}</p>}{feedback && <p className="inline-feedback success" role="status" data-testid="status-modal-submitted"><CircleCheck size={14} />{feedback}</p>}</form></div></div>;
}

function Home() {
  useAnimeInteractions();
  const [requestOpen, setRequestOpen] = useState(false);
  return <main className="site-shell"><div className="noise" aria-hidden="true" /><Hero onRequest={() => setRequestOpen(true)} /><TrustGap /><Boundary /><RuntimeConsole /><NetworkWatch /><ThreatModel /><Ledger /><Architecture /><Contact /><Footer />{requestOpen && <RequestModal onClose={() => setRequestOpen(false)} />}</main>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function PageMeta() {
  const [location] = useLocation();
  useEffect(() => {
    const notFound = location !== '/';
    document.title = notFound ? 'Page not found | Kosmos' : 'Kosmos — Runtime security for AI agents';
    const description = notFound
      ? 'This Kosmos page could not be found. Return to runtime security for autonomous AI agents.'
      : 'Kosmos verifies autonomous AI agent actions at tool-call time with visible policy decisions, explainable risk signals, and an auditable history.';
    document.querySelector('meta[name="description"]')?.setAttribute('content', description);
    document.querySelector('meta[property="og:title"]')?.setAttribute('content', document.title);
    document.querySelector('meta[property="og:description"]')?.setAttribute('content', description);
    document.querySelector('meta[name="twitter:title"]')?.setAttribute('content', document.title);
    document.querySelector('meta[name="twitter:description"]')?.setAttribute('content', description);
  }, [location]);
  return null;
}

function Router() {
  return <RoutedErrorBoundary><PageMeta /><Switch><Route path="/" component={Home} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}

function App() {
  return <TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider>;
}

export default App;