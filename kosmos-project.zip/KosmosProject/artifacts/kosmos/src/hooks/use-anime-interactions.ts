import { useEffect } from 'react';
import { animate } from 'animejs';

/**
 * Shared, pointer-aware CTA treatment. Anime owns scale/lift while CSS's
 * individual translate property handles the tiny magnetic offset.
 */
export function useAnimeInteractions(rootSelector?: string, refreshKey?: unknown) {
  useEffect(() => {
    const finePointer = window.matchMedia('(pointer: fine)').matches;
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const scope = rootSelector ? document.querySelector(rootSelector) : document;
    const targets = Array.from(scope?.querySelectorAll<HTMLElement>(
      'a, button, [role="button"]',
    ) ?? []);
    const active = new Map<HTMLElement, ReturnType<typeof animate>>();
    const cleanups: Array<() => void> = [];

    const play = (element: HTMLElement, hovered: boolean, pressed = false) => {
      active.get(element)?.cancel();
      const animation = animate(element, {
        scale: pressed ? 0.975 : hovered ? 1.05 : 1,
        translateY: pressed ? 0 : hovered ? -2 : 0,
        duration: reduceMotion ? 1 : pressed ? 90 : hovered ? 220 : 360,
        ease: hovered ? 'out(3)' : 'out(4)',
      });
      active.set(element, animation);
    };

    targets.forEach((element) => {
      if (element.matches(':disabled,[aria-disabled="true"]')) return;
      const onEnter = () => {
        element.dataset.ctaActive = 'true';
        play(element, true);
      };
      const onLeave = () => {
        delete element.dataset.ctaActive;
        element.style.removeProperty('--mag-x');
        element.style.removeProperty('--mag-y');
        play(element, false);
      };
      const onMove = (event: PointerEvent) => {
        const rect = element.getBoundingClientRect();
        element.style.setProperty('--glow-x', `${event.clientX - rect.left}px`);
        element.style.setProperty('--glow-y', `${event.clientY - rect.top}px`);
        if (finePointer && !reduceMotion) {
          element.style.setProperty('--mag-x', `${((event.clientX - rect.left) / rect.width - 0.5) * 4}px`);
          element.style.setProperty('--mag-y', `${((event.clientY - rect.top) / rect.height - 0.5) * 3}px`);
        }
      };
      const onDown = () => play(element, true, true);
      const onUp = () => play(element, true);
      const onFocus = () => { element.dataset.ctaActive = 'true'; play(element, true); };
      const onBlur = () => {
        delete element.dataset.ctaActive;
        element.style.removeProperty('--mag-x');
        element.style.removeProperty('--mag-y');
        play(element, false);
      };
      const onClick = () => {
        if (reduceMotion) return;
        element.dataset.clickGlow = 'true';
        element.addEventListener('animationend', () => delete element.dataset.clickGlow, { once: true });
      };
      element.addEventListener('pointerenter', onEnter);
      element.addEventListener('pointerleave', onLeave);
      element.addEventListener('pointermove', onMove);
      element.addEventListener('pointerdown', onDown);
      element.addEventListener('pointerup', onUp);
      element.addEventListener('pointercancel', onUp);
      element.addEventListener('focus', onFocus);
      element.addEventListener('blur', onBlur);
      element.addEventListener('click', onClick);
      cleanups.push(() => {
        element.removeEventListener('pointerenter', onEnter);
        element.removeEventListener('pointerleave', onLeave);
        element.removeEventListener('pointermove', onMove);
        element.removeEventListener('pointerdown', onDown);
        element.removeEventListener('pointerup', onUp);
        element.removeEventListener('pointercancel', onUp);
        element.removeEventListener('focus', onFocus);
        element.removeEventListener('blur', onBlur);
        element.removeEventListener('click', onClick);
        delete element.dataset.ctaActive;
        element.style.removeProperty('--mag-x');
        element.style.removeProperty('--mag-y');
        active.get(element)?.cancel();
      });
    });

    const hero = rootSelector ? null : document.querySelector<HTMLElement>('.hero');
    const onSceneMove = (event: PointerEvent) => {
      if (!finePointer || reduceMotion || !hero) return;
      const bounds = hero.getBoundingClientRect();
      hero.style.setProperty('--scene-x', `${((event.clientX - bounds.left) / bounds.width - 0.5) * -10}px`);
      hero.style.setProperty('--scene-y', `${((event.clientY - bounds.top) / bounds.height - 0.5) * -7}px`);
    };
    const resetScene = () => {
      hero?.style.removeProperty('--scene-x');
      hero?.style.removeProperty('--scene-y');
    };
    hero?.addEventListener('pointermove', onSceneMove);
    hero?.addEventListener('pointerleave', resetScene);
    return () => {
      cleanups.forEach((cleanup) => cleanup());
      hero?.removeEventListener('pointermove', onSceneMove);
      hero?.removeEventListener('pointerleave', resetScene);
      resetScene();
    };
  }, [rootSelector, refreshKey]);
}